
package supermercado;

import java.util.Scanner;

public class SuperMercado {
    
    int vet = 0;
    
    String produto[];
    int preco[];
    int qtd[];
    int id[] = new int[0];
    
    //Scanner
    Scanner in = new Scanner(System.in);
    
    public SuperMercado(){
        System.out.println("\n         Studio Market         \n");
        System.out.println("+-----------------------------+");        
        System.out.println("| Visualizar Produtos   -   1 |");
        System.out.println("| Adicionar Produtos    -   2 |");
        System.out.println("| Remover Produtos      -   3 |");
        System.out.println("| Editar Produto        -   4 |");
        System.out.println("+-----------------------------+ \n");
        
        
        System.out.print("| Opção: ");
        int op = in.nextInt();
        
        System.out.print("\n\n");        
        opc(op);
    }
    
    public void opc(int op){
    
        if(op == 1){
            if(id.length == 0){
                System.out.println("Você não tem nenhum produto em sua lista!");
                System.exit(0);
            }
            visu();
        }
        if(op == 2){
            System.out.print("\n\n\nQuantos produtos deseja adicionar? ");
                int pr = in.nextInt();
                
                    vet = vet + pr;
                    produto = new String[vet];
                    preco = new int[vet];
                    qtd = new int[vet];
                    id = new int[vet];
                    
                add(pr);
        }
        if(op == 3){
            if(id.length == 0){
                System.out.println("Você não tem nenhum produto em sua lista!");
                System.exit(0);
            }
            rem();
        }
        if(op != 1 && op != 2 && op != 3 && op != 4){
            System.out.println("Opção inválida!");
            System.exit(0);
        }
    }
    
    
    public void visu(){
        if(produto.length == 0){
            System.out.println("Nenhum Item Adicionado!");
            System.exit(0);
        }
        else {
            System.out.println("Produto -> Quantidade -> Valor -> ID");
            for(int i = 0; i < produto.length; i++){
                System.out.println("| " + produto[i] + "  -  " + qtd[i] + "  -  " + preco[i] + " - " + id[i] + " |");
            }
        }
    }
    
    public void add(int pr){
                        
        System.out.print("\n");
        
        for(int i = 0; i < pr; i++){
            System.out.print("\n");
            
            System.out.print("\n(SEM_ESPAÇO) Digite o nome do produto: ");
            produto[i] = in.next();
            
            System.out.print("\nDigite a quantidade do produto: ");
            qtd[i] = in.nextInt();
            
            System.out.print("\nDigite o valor do produto: ");
            preco[i] = in.nextInt();
            
            id[i] = i;
        }
        
        update();
        
    }
    
    public void rem(){
        
        int idRemover, removerConfirma;
        
        do{
            
            System.out.println("Qual ID você deseja remover?");
            idRemover = in.nextInt();

            if(idRemover == id[idRemover]){
                System.out.println("\n\n( ID para remover: |" + idRemover + "| ) - (1 - SIM / 2 - NÃO) Você confirma?");
            }
            else {
                System.out.println("ID inválido!");
                System.exit(0);
            }
            
            removerConfirma = in.nextInt();

                
        }while(removerConfirma != 1);
        
        if(removerConfirma == 1){
            produto[idRemover] = null;

            //int 
            id[idRemover] = 0;
            qtd[idRemover] = 0;
            preco[idRemover] = 0;
        }
        
    }
    
    public void update(){
        
        int op;
        
        do{
        
        System.out.println("\n\n\n\n         Studio Market         \n");
        System.out.println("+-----------------------------+");        
        System.out.println("| Visualizar Produtos   -   1 |");
        System.out.println("| Adicionar Produtos    -   2 |");
        System.out.println("| Remover Produtos      -   3 |");
        System.out.println("| Editar Produto        -   4 |");
        System.out.println("+-----------------------------+");
        System.out.println("| Stop                  -   5 |");
        System.out.println("+-----------------------------+ \n");
        
        
        System.out.print("| Opção: ");
        op = in.nextInt();
        
        System.out.print("\n\n"); 
        
        
        opc(op);

        }while(op != 5);
        
        if(op == 5){
            System.exit(0);
        }
        
    }
    
    
}
